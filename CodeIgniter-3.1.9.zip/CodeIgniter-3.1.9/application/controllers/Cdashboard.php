<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Cdashboard extends CI_Controller {
	
	function __construct() {
     	parent::__construct();
    }

    public function index(){

    	$CI =& get_instance();

	    $data = array(
	    				'title' => "Dashboard"
	    	         );

		$content = $CI->parser->parse('include/home',$data ,true);

		$this->template->full_html_view($content);
		
		
    }
}
