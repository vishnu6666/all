<html>
<body>
	<table align="center">
		<tr>
			<td>id</td>
			<td>name</td>
			<td>gender</td>
			<td>hobby</td>
			<td>education</td>
			<td>image</td>
			<td>gallery</td>
		</tr>
		<?php  
			foreach ($data as $row) {
		?>
		<tr>
			<td><?php echo $row->id;?></td>
			<td><?php echo $row->name;?></td>
			<td><?php echo $row->gender;?></td>
			<td><?php echo $row->hobby;?></td>
			<td><?php echo $row->education;?></td>
			<td>
				<img src="<?php echo base_url("my-assets/img/$row->image") ;?>" height="80" width="80"></td>
			<td><?php 
			$temp=explode(",",$row->gallery);
			for($i=0;$i<count($temp);$i++){
				?>
				<img src="<?php echo base_url("my-assets/imgs/$temp[$i]") ;?>" height="80" width="80"><?php }?></td>
			<td><a href="<?php echo base_url();?>Cform/delete/<?php echo $row->id;?>">Delete</a>
				<a href="<?php echo base_url();?>Cform/edit/<?php echo $row->id;?>">Edit</a></td>

		</tr>
		<?php } ?>
	</table>
</body>
</html>