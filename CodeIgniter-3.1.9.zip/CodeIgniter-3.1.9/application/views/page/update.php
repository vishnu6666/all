
  <div>
  	<p>welcome to codeigniter with form</p>
  </div>

<div class="container">
  <?php 
    foreach ($data as $row) {
    ?>
  	<form class="form-horizontal" action="<?php echo base_url();?>Cform/update" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="uid" value="<?php  echo $row->id;?>" hidden="">
    <div class="form-group">
      <label class="control-label col-sm-2" for="name" >Name:</label>
      <div class="col-sm-5">
        <input type="text" class="form-control" id="name" placeholder="Enter name" name="name" value="<?php echo $row->name?>">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="gender">Gender:</label>
      <div class="col-sm-10">          
        <input type="radio" name="gender" value="male" <?php if($row->gender=='male'){echo "checked";}?>>male
		    <input type="radio" name="gender" value="female" <?php if($row->gender=='female'){echo "checked";}?>>female				
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="name">Hobby:</label>
      <?php  $h=explode(",", $row->hobby);?>
      <div class="col-sm-10">
        <input type="checkbox" name="hobby[]" value="fb" <?php if(in_array('fb',$h)){echo"checked";}?>>fb
		    <input type="checkbox" name="hobby[]" value="wb" <?php if(in_array('wb',$h)){echo "checked";}?>>wb
		    <input type="checkbox" name="hobby[]" value="bb" <?php if(in_array('bb',$h)){echo "checked";}?>>bb
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="name">Education:</label>
      <div class="col-sm-10">
       <select name="education">
					<option <?php if($row->education=='Be'){echo "selected";}?>>Be</option>
					<option <?php if($row->education=='Me'){echo "selected";}?>>Me</option>
					<option <?php if($row->education=='Mtech'){echo "selected";}?>>Mtech</option>
		</select>
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="name">Image:</label>
      <div class="col-sm-10">
       <td><input type="file" name="img" >
        <img src="<?php echo base_url("my-asset/img/$row->image");?>" height="80" width="80">
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="name">Gallery:</label>
      <div class="col-sm-10">
        <td><input type="file" name="gallery[]" multiple="">
          <?php 
          $temp=explode(",", $row->gallery);
          for($i=0;$i<count($temp);$i++){?>
          <img src="<?php echo base_url("my-assets/imgs/$temp[$i]"); ?>" height="80" width="80"><?php } ?>
      </div>
    </div>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
       <input type="submit" name="update" >
      </div>
    </div>
  </form>
  <?php } ?>
</div>
 		

