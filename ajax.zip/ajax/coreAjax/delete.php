<?PHP
include("connect.php");
$id = $_GET['id'];
$sqld="DELETE FROM form WHERE id=$id";
$queryq=mysqli_query($con,$sqld);
/*print_r($queryq);exit();*/
if($queryq){
	echo"deleted";
}
else
{
	echo"error";
}
?>