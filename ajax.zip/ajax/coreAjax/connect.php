<?php
$con = mysqli_connect("localhost","root","","vakratund_db");
?>
