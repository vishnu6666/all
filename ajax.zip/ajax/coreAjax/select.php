<!DOCTYPE html>
<html>
<head>
	<title>CodeIgnitor</title>
	<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.2.1.min.js"></script>
	<script>
		$(document).ready(function()
		{
			$('.delete').click(function(e)
			{
				e.preventDefault();
				var id=$(this).attr('id');
				alert(id);
				$.ajax(
				{
					type:"POST",
					url:"delete.php",
					data:{ 'id':id },
					success:function(data)
					{
						alert(data);
						$.ajax(
						{
							type : "POST",
							url:"select.php",
							success:function(data)
							{
								$('#view').html(data);
							}
						});
					}
				});
				return false;
			});
		});

		$(function()
		{
			$('.update').click(function()
			{
				$('#add').hide();
				$('#upd').show();
				var id=$(this).attr('id');
				//alert(id);

				$('#cricket').prop('checked', false);
				$('#music').prop('checked', false);
				$('#dance').prop('checked', false);


				$.ajax(
				{
					type:"POST",
					url:"update.php",
					data:{ 'id' : id},
					success : function(data)
					{
						//alert(data);
						var dcdata = jQuery.parseJSON(data);
						//alert(dcdata[0].id);
						$('#uid').val(dcdata[0].id);
						$('#fname').val(dcdata[0].fname);
						$('#lname').val(dcdata[0].lname);
						if(dcdata[0].gender=="Male")
						{
							$('input:radio[name=gender]')[0].checked = true;
						}
						else
						{
							$('input:radio[name=gender]')[1].checked = true;
						}
						
						if(dcdata[0].education=="BCA")
						{
							$('#education').find('option:selected').text(dcdata[0].education);
						}
						if(dcdata[0].education=="MCA")
						{
							$('#education').find('option:selected').text(dcdata[0].education);
						}
						if(dcdata[0].education=="BBA")
						{
							$('#education').find('option:selected').text(dcdata[0].education);
						}
				
						var arr = new Array();
						var arr = dcdata[0].hobby.split(",");
							
						if($.inArray( "cricket", arr ) !== -1)
						{ 
							$('#cricket').prop('checked', true);
						}
						if($.inArray( "music", arr ) !== -1)
						{				
							$('#music').prop('checked', true);
						}
						if($.inArray( "dance", arr ) !== -1)
						{				
							$('#dance').prop('checked',true);
						}

						$('#pro').html('<img src="<?php echo base_url("upload/'+dcdata[0].profile+'"); ?>" width="50" height="50" >');

						
						$('#gallery').empty();
						var garr=dcdata[0].gallery.split(",");
						
						for(i=0;i<garr.length;i++)
						{
							$('#gallery').append('<img src="<?php echo base_url("upload/'+garr[i]+'");?>" width="50" height="50" >');
						}

					


						$.ajax(
						{
							type:"POST",
							url:"select.php",
							success:function(data)
							{
								$('#view').html(data);
							}
						});
					}
				});
				return false;
			});
		});
	</script>
</head>
<body>
<br><br>
	
	<form method="POST" action="<?php echo base_url(); ?>/index/Welcom/show">

		<table border="2" align="center">
			<tr>

				<th align="center" colspan="8">--- Records in Table ---</th>	
			</tr>
			<tr>
				<th>First name</th>
				<th>Last name</th>
				<th>Gender</th>
				<th>Education</th>
				<th>Hobby</th>
				<th>Profile</th>
				<th>Gallery</th>
				<th>Action</th>
			</tr>
			<?php
				foreach($data as $raw)
				{?>
					<tr>
						<td><?php echo $raw->fname; ?></td>
						<td><?php echo $raw->lname; ?></td>
						<td><?php echo $raw->gender; ?></td>
						<td><?php echo $raw->education; ?></td>
						<td><?php echo $raw->hobby; ?></td>
						<td align="center">
							<img src="<?php echo base_url("upload/$raw->profile"); ?>" width="50" height="50">
						</td>
						<td>

						<?php $gal=explode(",",$raw->gallery);
							for ($i=0; $i <count($gal); $i++) 
							{ ?>
								<img src="<?php echo base_url("upload/$gal[$i]"); ?>" height="50" width="50">	 	
						<?php } 
							?>

						</td>
						<td>
							<a href="#" id="<?php echo $raw->id; ?>" class="update">Edit</a>  ||  <a href="#" id="<?php echo $raw->id; ?>" class="delete">Delete</a> 
						</td>	
					</tr>
			<?php }
			?>
			
		</table>
	</form>
	
</body>
</html>