<?php
include("connect.php");
	 $name=$_POST['name'];
	 $gender=$_POST['gender'];
	 $hb=$_POST['hobby'];
	 $hobby=implode(",",$hb);
	 $education=$_POST['education'];
	 $file=$_FILES['file']['name'];
	move_uploaded_file($_FILES['file']['tmp_name'],"fs/$file");
	$sql="INSERT INTO form (name,gender,hobby,education,file)VALUES('$name','$gender','$hobby','$education','$file')";
	/*print_r($sql);
	exit();*/
	if(mysqli_query($con,$sql))
	{
		echo"submited";
	}
	else
	{
		echo"not ok";
	}

?>